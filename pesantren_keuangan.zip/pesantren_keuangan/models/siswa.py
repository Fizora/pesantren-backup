from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models
from odoo.exceptions import UserError

class SiswaInherit(models.Model):
    _inherit        = 'cdn.siswa'

    limit           = fields.Selection(selection=[
        ('hari', 'Perhari'),
        ('minggu', 'Perminggu'),
        ('bulan', 'Bulan'),
    ], string='Periode')

    amount              = fields.Float(string="Total", digits=(16, 0))
    used_amount         = fields.Float(string="Jumlah Terpakai", digits=(16, 0), default=0)
    limit_reset_date    = fields.Datetime(string="Tanggal Reset Limit", readonly=True)
    is_limit_active     = fields.Boolean(string="Limit Aktif", default=False)
    remaining_limit     = fields.Float(string="Sisa Limit", digits=(16, 0) ,compute="_compute_remaining_limit")

    def _reset_expired_limits(self):
        """Fungsi scheduler untuk reset limit yang sudah expired"""
        now = fields.Datetime.now()
        expired_limits = self.search([
            ('is_limit_active', '=', True),
            ('limit_reset_date', '<=', now)
        ])
        
        for santri in expired_limits:
            reset_date = now
            if santri.limit == 'hari':
                reset_date = now + relativedelta(days=1)
            elif santri.limit == 'minggu':
                reset_date = now + relativedelta(weeks=1)
            elif santri.limit == 'bulan':
                reset_date = now + relativedelta(months=1)
            
            santri.write({
                'used_amount': 0,
                'limit_reset_date': reset_date,
            })


    @api.depends('amount', 'used_amount')
    def _compute_remaining_limit(self):
        for record in self:
            record.remaining_limit = record.amount - record.used_amount

    def create_data_account(self):
        self.partner_id.create_data_account()

    def action_view_pos_order(self):
        action = self.env["ir.actions.actions"]._for_xml_id("pesantren_keuangan.pos_order_action_internal")
        action['domain'] = [('partner_id', '=', self.partner_id.id)]
        action['context'] = {'partner_id': self.partner_id.id}
        return action
        
    pos_order_count = fields.Integer(string='POS Orders', compute='_compute_pos_order_count')
    
    @api.depends('partner_id')
    def _compute_pos_order_count(self):
        for siswa in self:
            siswa.pos_order_count = self.env['pos.order'].search_count([('partner_id', '=', siswa.partner_id.id)])

    def action_setlimit(self):
        context = dict(self.env.context)
        active_ids = context.get('active_ids', [])

        return {
            'name': 'Atur Limit Penggunaan Saldo',
            'type': 'ir.actions.act_window',
            'res_model': 'set.limit.santri',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_partner_ids': active_ids}
        }


