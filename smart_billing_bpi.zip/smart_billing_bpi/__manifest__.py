{
    'name': 'Smart Billing BPI',
    'version': '1.0',
    'summary': 'Modul pembayaran tagihan untuk integrasi SNAP BI',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'views/tagihan_views.xml',
    ],
    'installable': True,
    'application': True,
}
