from odoo import http, fields
from odoo.http import request

class SmartBillingController(http.Controller):

    @http.route('/auth', type='json', auth='public', methods=['POST'], csrf=False)
    def auth(self, **post):
        client_id = post.get('client_id')
        client_secret = post.get('client_secret')
        if client_id == 'SBI0001' and client_secret == 'ABCDEF12345678':
            return {'status': 'success', 'message': 'Authorized'}
        return {'status': 'failed', 'message': 'Invalid credentials'}

    @http.route('/inquiry', type='json', auth='public', methods=['POST'], csrf=False)
    def inquiry(self, **post):
        id_invoice = post.get('id_invoice')
        tagihan = request.env['tagihan.pembayaran'].sudo().search([('id_invoice', '=', id_invoice)], limit=1)
        if tagihan:
            return {
                'status': 'success',
                'data': {
                    'id_invoice': tagihan.id_invoice,
                    'nama': tagihan.nama,
                    'nomor_siswa': tagihan.nomor_siswa,
                    'jumlah': tagihan.nominal_tagihan,
                    'status': tagihan.status_pembayaran
                }
            }
        return {'status': 'failed', 'message': 'Tagihan tidak ditemukan'}

    @http.route('/payment', type='json', auth='public', methods=['POST'], csrf=False)
    def payment(self, **post):
        id_invoice = post.get('id_invoice')
        tagihan = request.env['tagihan.pembayaran'].sudo().search([('id_invoice', '=', id_invoice)], limit=1)
        if tagihan:
            tagihan.write({
                'status_pembayaran': 'SUKSES',
                'waktu_transaksi': fields.Datetime.now(),
                'channel_pembayaran': post.get('channel_pembayaran', 'API')
            })
            return {'status': 'success', 'message': 'Pembayaran berhasil diproses'}
        return {'status': 'failed', 'message': 'Tagihan tidak ditemukan'}
