from odoo import models, fields

class TagihanPembayaran(models.Model):
    _name = 'tagihan.pembayaran'
    _description = 'Tagihan Pembayaran'

    id_invoice = fields.Char(string='ID Invoice', required=True)
    tanggal_invoice = fields.Date(string='Tanggal Invoice', required=True)
    nomor_siswa = fields.Char(string='Nomor Siswa', required=True)
    nama = fields.Char(string='Nama', required=True)
    nominal_tagihan = fields.Integer(string='Nominal Tagihan', required=True)
    informasi = fields.Char(string='Informasi', required=True)
    nomor_jurnal_pembukuan = fields.Char(string='Nomor Jurnal Pembukuan')
    waktu_transaksi = fields.Datetime(string='Waktu Transaksi')
    channel_pembayaran = fields.Char(string='Channel Pembayaran')
    status_pembayaran = fields.Char(string='Status Pembayaran')