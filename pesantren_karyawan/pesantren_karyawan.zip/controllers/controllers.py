# -*- coding: utf-8 -*-
from odoo.exceptions import UserError
from odoo import http
from odoo.http import request
from datetime import date
import json
from datetime import datetime
import base64
import tempfile
import os
import random
import hashlib
import locale


class UbigKaryawanController(http.Controller):
    @http.route('/pendaftaran_karyawan', type='http', auth='public')
    def pendaftaran_karyawan_form(self, **kwargs):

        jabatan_kerja_list = request.env['hr.job'].sudo().search([('name', '!=', 'Kepala Kepesantrenan')])
        return request.render('pesantren_karyawan.pendaftaran_karyawan_form_template', {
            'jabatan_kerja_list': jabatan_kerja_list,
        })
    
    @http.route('/pendaftaran_karyawan/submit', type='http', auth='public', methods=['POST'], csrf=True)
    def pendaftaran_karyawan_submit(self, **post):

        # Ambil data dari form
        name                   = post.get('name')
        email_kantor           = post.get('email_kantor')
        no_ktp                 = post.get('no_ktp')
        no_telp                = post.get('no_telp')
        tgl_lahir_str          = request.params.get('tgl_lahir')
        # Mengonversi format tanggal dd/mm/yyyy menjadi date
        tgl_lahir              = datetime.datetime.strptime(tgl_lahir_str, '%d/%m/%Y').date()
        alamat                 = post.get('alamat')
        tmp_lahir              = post.get('tmp_lahir')
        gender                 = request.params.get('gender')
        lembaga                = request.params.get('lembaga')
        jabatan_kerja          = request.params.get('jabatan_kerja')

        # Data Berkas
        # Ambil file dari request
        uploaded_files = request.httprequest.files

        # Ambil setiap file, konversi ke Base64, dan proses
        cv = uploaded_files.get('cv')
        ktp = uploaded_files.get('ktp')
        npwp = uploaded_files.get('npwp')
        ijazah = uploaded_files.get('ijazah')
        pas_foto = uploaded_files.get('pas_foto')
        sertifikat = uploaded_files.get('sertifikat')
        surat_pengalaman = uploaded_files.get('surat_pengalaman')
        surat_kesehatan = uploaded_files.get('surat_kesehatan')

        # Fungsi bantu untuk memproses file
        def process_file(file):
            if file:
                # Baca file dan konversi ke Base64
                file_content = file.read()
                file_base64 = base64.b64encode(file_content)
                return file_base64
            return None

        # Konversi file yang diunggah
        cv_b64 = process_file(cv)
        ktp_b64 = process_file(ktp)
        npwp_b64 = process_file(npwp)
        ijazah_b64 = process_file(ijazah)
        pas_foto_b64 = process_file(pas_foto)
        sertifikat_b64 = process_file(sertifikat)
        surat_pengalaman_b64 = process_file(surat_pengalaman)
        surat_kesehatan_b64 = process_file(surat_kesehatan)

        # Buat record di hr.candidate
        candidate = request.env['hr.candidate'].sudo().create({
            'name': name,
        })

        # Simpan data ke model ubig.karyawan
        pendaftaran = request.env['ubig.karyawan'].sudo().create({
            # 'kode_akses'             : kode_akses,
            'name'                   : name,
            'email_kantor'           : email_kantor,
            'no_ktp'                 : no_ktp,
            'no_telp'                : no_telp,
            'tgl_lahir'              : tgl_lahir,
            'alamat'                 : alamat,
            'tmp_lahir'              : tmp_lahir,
            'gender'                 : gender,
            'lembaga'                : lembaga,
            'jabatan_kerja'          : jabatan_kerja,

            # Data Berkas
            'cv'                     : cv_b64 if cv_b64 else False,
            'ktp'                    : ktp_b64 if ktp_b64 else False,
            'npwp'                   : npwp_b64 if npwp_b64 else False,
            'ijazah'                 : ijazah_b64 if ijazah_b64 else False,
            'pas_foto'               : pas_foto_b64 if pas_foto_b64 else False,
            'sertifikat'             : sertifikat_b64 if sertifikat_b64 else False,
            'surat_kesehatan'        : surat_kesehatan_b64 if surat_kesehatan_b64 else False,
            'surat_pengalaman'       : surat_pengalaman_b64 if surat_pengalaman_b64 else False,
            'state'                  : 'draft'  # set status awal menjadi 'terdaftar'
        })

        token = pendaftaran.token

        # Redirect ke halaman sukses atau halaman lain yang diinginkan
        return request.redirect(f'/pendaftaran_karyawan/success?token={token}')
    
    @http.route('/pendaftaran_karyawan/success', type='http', auth='public')
    def pendaftaran_karyawan_success(self, token=None, **kwargs):

        Pendaftaran = request.env['ubig.karyawan']

        # Menangkap Token pendaftaran dari URL
        token = request.params.get('token')

        if not token:
            return request.not_found()

        # Cari pendaftaran berdasarkan token
        pendaftaran = Pendaftaran.sudo().search([('token', '=', token)], limit=1)
        if not pendaftaran:
            return request.not_found()

        # Kirim email
        if pendaftaran.email_kantor:
            thn_sekarang = datetime.datetime.now().year
            email_values = {
                'subject': "Informasi Pendaftaran Karyawan Pesantren Daarul Qur'an Istiqomah",
                'email_to': pendaftaran.email_kantor,
                'body_html': f'''
                    <div style="background-color: #d9eaf7; padding: 20px; font-family: Arial, sans-serif;">
                        <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; overflow: hidden;">
                            <!-- Header -->
                            <div style="background-color: #0066cc; color: #ffffff; text-align: center; padding: 20px;">
                                <h1 style="margin: 0; font-size: 24px;">Pesantren Daarul Qur'an Istiqomah</h1>
                            </div>
                            <!-- Body -->
                            <div style="padding: 20px; color: #555555;">
                                <p style="margin: 0 0 10px;">Assalamualaikum Wr. Wb,</p>
                                <p style="margin: 0 0 20px;">
                                    Bapak/Ibu <strong>{pendaftaran.name}</strong>,<br>
                                    Terima kasih anda telah melamar di pesantren kami. Berikut adalah informasi data pendaftaran anda:
                                </p>
                                <div style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0;">

                                    <h3>Data Pendaftaran Karyawan</h3>
                                    <table style="width: 100%; border-collapse: collapse;">
                                        <tr>
                                            <td style="padding: 8px; font-weight: bold; color: #333333;">Nama :</td>
                                            <td style="padding: 8px; color: #555555;">{pendaftaran.name}</td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 8px; font-weight: bold; color: #333333;">TTL :</td>
                                            <td style="padding: 8px; color: #555555;">{pendaftaran.tmp_lahir}, {pendaftaran.get_formatted_tanggal_lahir()}</td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 8px; font-weight: bold; color: #333333;">Alamat :</td>
                                            <td style="padding: 8px; color: #555555;">{pendaftaran.alamat}</td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 8px; font-weight: bold; color: #333333;">Lembaga :</td>
                                            <td style="padding: 8px; color: #555555;">{pendaftaran.lembaga.replace('paud', 'PAUD').replace('tk', 'TK').replace('sd', 'SD').replace('smpmts', 'SMP / MTS').replace('smama', 'SMA / MA').replace('smk', 'SMK')}</td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 8px; font-weight: bold; color: #333333;">Jabatan Kerja :</td>
                                            <td style="padding: 8px; color: #555555;">{pendaftaran.jabatan_kerja.name}</td>
                                        </tr>
                                    </table>

                                </div>
                                <p style="margin: 20px 0;">
                                    Apabila terdapat kesulitan atau membutuhkan bantuan, silakan hubungi tim teknis kami melalui nomor:
                                </p>
                                <ul style="margin: 0; padding-left: 20px; color: #555555;">
                                    <li>0822 5207 9785</li>
                                    <li>0853 9051 1124</li>
                                </ul>
                                <p style="margin: 20px 0;">
                                    Kami berharap portal ini dapat membantu Bapak/Ibu memantau perkembangan putra/putri selama berada di pesantren.
                                </p>
                            </div>
                            <!-- Footer -->
                            <div style="background-color: #f1f1f1; text-align: center; padding: 10px;">
                                <p style="font-size: 12px; color: #888888; margin: 0;">
                                    &copy; {thn_sekarang} Pesantren Tahfizh Daarul Qur'an Istiqomah. All rights reserved.
                                </p>
                            </div>
                        </div>
                    </div>
                ''',
            }

            mail = request.env['mail.mail'].sudo().create(email_values)
            mail.send()

        return request.render('pesantren_karyawan.pendaftaran_karyawan_success_template', {
            'pendaftaran': pendaftaran,
        })


