from . import res_partner
from . import pos_wallet_transaction
from . import hr_employee
# from . import keterangan
